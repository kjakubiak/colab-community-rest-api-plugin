package sailpoint.community.rest;

import java.util.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.integration.ListResult;
import sailpoint.object.Bundle;
import sailpoint.object.QueryOptions;
import sailpoint.object.Filter;
import sailpoint.object.WorkItem;
import sailpoint.object.Identity;
import sailpoint.rest.plugin.BasePluginResource;
import sailpoint.rest.plugin.RequiredRight;
import sailpoint.tools.GeneralException;

@RequiredRight(value = "communityRestCounterResource")
@Path("/Count")
public class CounterResource extends BasePluginResource {
    public static final Log log = LogFactory.getLog(RoleResource.class);
    private static SailPointContext context;
    private static final int PRETTY_PRINT_INDENT_FACTOR = 4;
    private void initConfig() throws GeneralException {
        context = SailPointFactory.getCurrentContext();


    }
    @GET
    @Path("/Approvals")
    @Produces(MediaType.APPLICATION_JSON)
    public Response countApprovals(@QueryParam("identity") String identityIdOrName) throws GeneralException {
        initConfig();
        Identity identity = context.getObject(Identity.class,identityIdOrName);

        QueryOptions qo = new QueryOptions();
        qo.addFilter(Filter.eq("owner.id",identity.getId()));
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        Map<String,Integer> returnMap = new HashMap<>();
        returnMap.put("total",context.countObjects(WorkItem.class,qo));

        return Response.status(200).entity(gson.toJson(returnMap)).build();
    }

    @Override
    public String getPluginName() {
        return "communityrestapi";
    }
}
