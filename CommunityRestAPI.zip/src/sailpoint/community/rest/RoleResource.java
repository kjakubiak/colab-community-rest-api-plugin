package sailpoint.community.rest;

import java.util.*;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import com.google.gson.Gson;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import sailpoint.api.SailPointContext;
import sailpoint.api.SailPointFactory;
import sailpoint.integration.ListResult;
import sailpoint.object.Bundle;
import sailpoint.rest.plugin.BasePluginResource;
import sailpoint.rest.plugin.RequiredRight;
import sailpoint.tools.GeneralException;

@RequiredRight(value = "communityRestRoleResource")
@Path("/Roles")
public class RoleResource extends BasePluginResource {
	public static final Log log = LogFactory.getLog(RoleResource.class);
 	private static SailPointContext context;
	 private static final int PRETTY_PRINT_INDENT_FACTOR = 4;
	private void initConfig() throws GeneralException {
		context = SailPointFactory.getCurrentContext();


	}
	private void checkRequiredAttributes(Map<String, Object> attributes) throws GeneralException {
		if (attributes.get("name") == null) {
			throw new GeneralException("Role name is required");
		}
		if (attributes.get("description") == null) {
			throw new GeneralException("Role description is required");
		}
		if (attributes.get("type") == null) {
			throw new GeneralException("Role type is required");
		}
	}
	@POST
	@Path("/create")
 	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String createRole(Map<String, Object> attributes) throws GeneralException {
		initConfig();
		checkRequiredAttributes(attributes);
		if(context.getObject(Bundle.class, (String) attributes.get("name")) != null) {
			throw new GeneralException("Role with name " + attributes.get("name") + " already exists");
		}
		Bundle role = new Bundle();
		for(String key : attributes.keySet()) {
			role.setAttribute(key, attributes.get(key));
		}

		context.saveObject(role);
		context.commitTransaction();
		return role.toXml();
	}


	@Override
	public String getPluginName() {
		return "communityrestapi";
	}
}
